package com.example.proyek_mdp.Data.local.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.proyek_mdp.Data.local.dao.PostDao
import com.example.proyek_mdp.Data.local.dao.UserDao
import com.example.proyek_mdp.Data.local.entity.PaymentHistory
import com.example.proyek_mdp.Data.local.dao.PaymentHistoryDao
import com.example.proyek_mdp.Data.local.entity.Post
import com.example.proyek_mdp.Data.local.entity.PurchaseHistory
import com.example.proyek_mdp.Data.local.dao.PurchaseHistoryDao
import com.example.proyek_mdp.Data.local.entity.User
import com.example.proyek_mdp.Data.local.entity.UserInventory
import com.example.proyek_mdp.Data.local.dao.UserInventoryDao

@Database(
    entities = [
        User::class,
        Post::class,
        UserInventory::class,
        PaymentHistory::class,
        PurchaseHistory::class
    ],
    version = 9,
    exportSchema = false
)

abstract class AppDatabase : RoomDatabase() {

    abstract fun paymentHistoryDao(): PaymentHistoryDao
    abstract fun purchaseHistoryDao(): PurchaseHistoryDao
    abstract fun userDao(): UserDao
    abstract fun postDao(): PostDao
    abstract fun userInventoryDao(): UserInventoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "pokemon_db"
                )
                    .fallbackToDestructiveMigration() // SANGAT PENTING agar tidak crash saat versi naik
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}