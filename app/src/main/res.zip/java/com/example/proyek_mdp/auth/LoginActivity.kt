package com.example.proyek_mdp.auth

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.example.proyek_mdp.MainActivity
import com.example.proyek_mdp.R
import com.example.proyek_mdp.admin.AdminActivity
import com.example.proyek_mdp.viewmodel.LoginViewModel
import com.example.proyek_mdp.viewmodel.ViewModelFactory
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    private lateinit var etUsername: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var tvRegister: TextView

    private val viewModel: LoginViewModel by viewModels {
        ViewModelFactory(applicationContext)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        etUsername = findViewById(R.id.etUsername)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        tvRegister = findViewById(R.id.tvRegister)

        btnLogin.setOnClickListener {

            val username = etUsername.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(
                    this,
                    "Username dan Password harus diisi",
                    Toast.LENGTH_SHORT
                ).show()
                return@setOnClickListener
            }

            // Login Admin
            if (username == "admin" && password == "admin") {

                Toast.makeText(
                    this,
                    "Login Admin Berhasil",
                    Toast.LENGTH_SHORT
                ).show()

                startActivity(
                    Intent(
                        this,
                        AdminActivity::class.java
                    )
                )

                finish()
                return@setOnClickListener
            }

            // Login User
            lifecycleScope.launch {

                val user = viewModel.login(
                    username,
                    password
                )

                if (user != null) {

                    SessionManager(this@LoginActivity)
                        .saveSession(
                            user.id,
                            user.username
                        )

                    Toast.makeText(
                        this@LoginActivity,
                        "Login Berhasil",
                        Toast.LENGTH_SHORT
                    ).show()

                    val targetActivity =
                        if (user.hasSelectedStarter == 0) {
                            StarterSelectionActivity::class.java
                        } else {
                            MainActivity::class.java
                        }

                    startActivity(
                        Intent(
                            this@LoginActivity,
                            targetActivity
                        )
                    )

                    finish()

                } else {

                    Toast.makeText(
                        this@LoginActivity,
                        "Username atau Password salah",
                        Toast.LENGTH_SHORT
                    ).show()

                }
            }
        }

        tvRegister.setOnClickListener {
            startActivity(
                Intent(
                    this,
                    RegisterActivity::class.java
                )
            )
        }
    }
}