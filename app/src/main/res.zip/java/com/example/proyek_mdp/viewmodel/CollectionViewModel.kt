package com.example.proyek_mdp.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.proyek_mdp.Data.local.entity.PokemonEntity
import com.example.proyek_mdp.Data.repository.InventoryRepository
import com.example.proyek_mdp.Data.repository.PokemonRepository
import com.example.proyek_mdp.Data.repository.PostRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class CollectionViewModel(
    private val repository: PokemonRepository,
    inventoryRepository: InventoryRepository,
    postRepository: PostRepository
) : ViewModel() {

    private val _pokemonList = MutableStateFlow<List<PokemonEntity>>(emptyList())
    val pokemonList: StateFlow<List<PokemonEntity>> = _pokemonList

    fun loadPokemon(userId: Int) {
        viewModelScope.launch {
            _pokemonList.value = repository.getPokemonByUser(userId)
        }
    }

    fun toggleLock(pokemon: PokemonEntity) {
        viewModelScope.launch {

            val lock =
                if (pokemon.isLocked == 1) 0
                else 1

            repository.updatePokemon(
                pokemon.copy(isLocked = lock)
            )

            loadPokemon(pokemon.userId)
        }
    }

    fun deletePokemon(pokemon: PokemonEntity) {

        viewModelScope.launch {

            repository.deletePokemon(pokemon)

            loadPokemon(pokemon.userId)

        }
    }

    fun deleteAllUnlocked(userId: Int) {

        viewModelScope.launch {

            repository.deleteAllUnlockedByUser(userId)

            loadPokemon(userId)

        }
    }
}